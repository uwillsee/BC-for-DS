BC5 1_Data Understanding and Cleaning:
	- Initial Processing, mainly to reduce the file size, number of data points, and memoery usage

BC5_2 Product Group Level Relationships:
	- A part of Data Understanding/Cleaning Process. It looks at the nature of relationship among different product groups.


BC5_3 Main_Quantity:
	- Main analysis of the quantity data


BC5_4 Supplement_Revenue:
	- Extra analysis done for revenue element, following very similar approach as quantity element analysis. Redundant (product co-occurrence and clustering) were excluded. Revenue level analysis was not requested by our client.